const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["6285852129763@s.whatsapp.net"]
global.nomerOwner = "6285852129763"
global.nomorOwner = ['6285852129763']
global.namaDeveloper = "YogzzDevX"
global.namaBot = "AsaMitaka Botz"
global.packname = "Asa Mitaka"
global.author = "By YogzzDevX"
global.thumb = fs.readFileSync("./thumb.png")
global.qris = fs.readFileSync("./qris.jpg")
global.tekspushkon = ""
global.tekspushkonv1 = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tiktok = 'https://tiktok.com/@iamsrebeh'
global.dana = '-'
global.gopay = '-'
global.ovo = '-'
global.pulsa = '-'

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})

/*

Thanks To By KirBotz
Di Tulis Dan Di Fix Oleh ZIRO
Buy No Enc? 6285807405071 ( YogzzDevX )

*/